var annotated_dup =
[
    [ "Compact_String", "d0/d2d/class_compact___string.html", null ],
    [ "Crawler", "dc/da4/class_crawler.html", "dc/da4/class_crawler" ],
    [ "DatabaseConnection", "d7/dcc/class_database_connection.html", "d7/dcc/class_database_connection" ],
    [ "DBManager", "d8/d9e/class_d_b_manager.html", null ],
    [ "entry", "d8/df9/classentry.html", "d8/df9/classentry" ],
    [ "extract", "dd/d0e/classextract.html", null ],
    [ "GUI", "d3/d57/class_g_u_i.html", "d3/d57/class_g_u_i" ],
    [ "indexer", "db/d30/classindexer.html", "db/d30/classindexer" ],
    [ "mainEngine", "d5/daa/classmain_engine.html", null ],
    [ "MongoConnection", "da/dd8/class_mongo_connection.html", null ],
    [ "pageRank", "d8/db9/classpage_rank.html", null ],
    [ "PageRankByRelevance", "da/dcf/class_page_rank_by_relevance.html", null ],
    [ "phraseSearching", "d4/dee/classphrase_searching.html", null ],
    [ "QueryProcessor", "df/d2e/class_query_processor.html", null ],
    [ "RobotParser", "de/da6/class_robot_parser.html", null ],
    [ "RobotRule", "d5/d01/class_robot_rule.html", "d5/d01/class_robot_rule" ],
    [ "script", "d7/d29/classscript.html", null ],
    [ "splitPage", "d1/d80/classsplit_page.html", "d1/d80/classsplit_page" ],
    [ "stemmer", "d1/dc2/classstemmer.html", "d1/dc2/classstemmer" ]
];