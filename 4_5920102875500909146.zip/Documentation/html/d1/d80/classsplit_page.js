var classsplit_page =
[
    [ "readFile", "d1/d80/classsplit_page.html#a4315615b36ea1dc9a2c589d4156dece6", null ],
    [ "split", "d1/d80/classsplit_page.html#aa94c2b9a9a9c0de82d70d4d02a0b584a", null ]
];