var _page_rank_by_relevance_8java =
[
    [ "PageRankByRelevance", "da/dcf/class_page_rank_by_relevance.html", null ]
];