var stemmer_8java =
[
    [ "stemmer", "d1/dc2/classstemmer.html", "d1/dc2/classstemmer" ]
];