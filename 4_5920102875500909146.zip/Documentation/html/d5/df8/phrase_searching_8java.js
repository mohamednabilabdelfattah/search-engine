var phrase_searching_8java =
[
    [ "phraseSearching", "d4/dee/classphrase_searching.html", null ]
];