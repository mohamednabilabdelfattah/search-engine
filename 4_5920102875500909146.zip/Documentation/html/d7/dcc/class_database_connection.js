var class_database_connection =
[
    [ "connect", "d7/dcc/class_database_connection.html#ae726f1f6760f1a1cedee9404134533e9", null ]
];