var _query_processor_8java =
[
    [ "QueryProcessor", "df/d2e/class_query_processor.html", null ]
];