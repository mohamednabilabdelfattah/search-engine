var _crawler_8java =
[
    [ "Crawler", "dc/da4/class_crawler.html", "dc/da4/class_crawler" ]
];