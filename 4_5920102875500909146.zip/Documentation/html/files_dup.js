var files_dup =
[
    [ "Compact_String.java", "d4/d51/_compact___string_8java.html", "d4/d51/_compact___string_8java" ],
    [ "Crawler.java", "de/d71/_crawler_8java.html", "de/d71/_crawler_8java" ],
    [ "DatabaseConnection.java", "d3/dcd/_database_connection_8java.html", "d3/dcd/_database_connection_8java" ],
    [ "DBManager.java", "d7/d8d/_d_b_manager_8java.html", "d7/d8d/_d_b_manager_8java" ],
    [ "entry.java", "db/d9c/entry_8java.html", "db/d9c/entry_8java" ],
    [ "extract.java", "d3/d19/extract_8java.html", "d3/d19/extract_8java" ],
    [ "GUI.java", "d0/d0f/_g_u_i_8java.html", "d0/d0f/_g_u_i_8java" ],
    [ "indexer.java", "db/d94/indexer_8java.html", "db/d94/indexer_8java" ],
    [ "mainEngine.java", "d2/d1d/main_engine_8java.html", "d2/d1d/main_engine_8java" ],
    [ "MongoConnection.java", "dd/d41/_mongo_connection_8java.html", "dd/d41/_mongo_connection_8java" ],
    [ "pageRank.java", "d9/d9f/page_rank_8java.html", "d9/d9f/page_rank_8java" ],
    [ "PageRankByRelevance.java", "d2/de0/_page_rank_by_relevance_8java.html", "d2/de0/_page_rank_by_relevance_8java" ],
    [ "phraseSearching.java", "d5/df8/phrase_searching_8java.html", "d5/df8/phrase_searching_8java" ],
    [ "QueryProcessor.java", "da/da3/_query_processor_8java.html", "da/da3/_query_processor_8java" ],
    [ "RobotParser.java", "dc/d64/_robot_parser_8java.html", "dc/d64/_robot_parser_8java" ],
    [ "RobotRule.java", "d8/db6/_robot_rule_8java.html", "d8/db6/_robot_rule_8java" ],
    [ "script.java", "d6/d28/script_8java.html", "d6/d28/script_8java" ],
    [ "splitPage.java", "d3/d31/split_page_8java.html", "d3/d31/split_page_8java" ],
    [ "stemmer.java", "d2/ded/stemmer_8java.html", "d2/ded/stemmer_8java" ]
];