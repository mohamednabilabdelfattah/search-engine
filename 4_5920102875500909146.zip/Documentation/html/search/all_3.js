var searchData=
[
  ['getfromqueries_0',['getFromQueries',['../d8/d9e/class_d_b_manager.html#a4bb2c40c82bf875242aa98b08fcfda16',1,'DBManager']]],
  ['getnumberofcrawledpages_1',['getNumberOfCrawledPages',['../d8/d9e/class_d_b_manager.html#a90b0e3d04b6c0ac6a899650c555a8b10',1,'DBManager']]],
  ['getnumofcrawledurls_2',['getNumOfCrawledURLS',['../d8/d9e/class_d_b_manager.html#a40fbdc8d74f28d884ac6c2a7b4800cd9',1,'DBManager']]],
  ['getnumofindexed_3',['getNumOfIndexed',['../d8/d9e/class_d_b_manager.html#abea300b29c57b35b678a1761124063a1',1,'DBManager']]],
  ['getonebodyandtitlefromcrawledv2_4',['getOneBodyAndTitleFromCrawledv2',['../d8/d9e/class_d_b_manager.html#a900c74decd372cf807b27afcca5ab9e5',1,'DBManager']]],
  ['getonebodyfromcrawledv2_5',['getOneBodyFromCrawledv2',['../d8/d9e/class_d_b_manager.html#ae9926be01400dfd5b905128e0aadb1b3',1,'DBManager']]],
  ['getoneurl_6',['getOneURL',['../d8/d9e/class_d_b_manager.html#ac6723763cb6e2a042f9634dd891b7e1f',1,'DBManager']]],
  ['getoneurlfromcrawled_7',['getOneURLFromCrawled',['../d8/d9e/class_d_b_manager.html#a5199bd51c819afa4a340716674e826d9',1,'DBManager']]],
  ['gett_5fdfscores_8',['getT_DFScores',['../da/dd8/class_mongo_connection.html#a8a2f03caf8ec85778dba3d0c76f48970',1,'MongoConnection']]],
  ['gettherankofurl_9',['getTheRankOfURL',['../d8/d9e/class_d_b_manager.html#a937b56ae6cd150cf6b00e06654198bea',1,'DBManager']]],
  ['gui_10',['GUI',['../d3/d57/class_g_u_i.html',1,'GUI'],['../d3/d57/class_g_u_i.html#a35a15f9dcfca9111335e4401a46567ed',1,'GUI.GUI()']]],
  ['gui_2ejava_11',['GUI.java',['../d0/d0f/_g_u_i_8java.html',1,'']]]
];
