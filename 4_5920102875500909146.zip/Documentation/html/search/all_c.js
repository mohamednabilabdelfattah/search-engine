var searchData=
[
  ['updatetherankoftheurl_0',['updateTheRankOfTheURL',['../d8/d9e/class_d_b_manager.html#a1a06c0ab17c245a02e6c637e89d7cc08',1,'DBManager']]],
  ['useragent_1',['userAgent',['../d5/d01/class_robot_rule.html#a6650aa58c0ea915d3be2b19b9a40f54f',1,'RobotRule']]]
];
