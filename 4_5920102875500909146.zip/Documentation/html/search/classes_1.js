var searchData=
[
  ['databaseconnection_0',['DatabaseConnection',['../d7/dcc/class_database_connection.html',1,'']]],
  ['dbmanager_1',['DBManager',['../d8/d9e/class_d_b_manager.html',1,'']]]
];
