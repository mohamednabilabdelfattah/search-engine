var searchData=
[
  ['pagerank_0',['pageRank',['../d8/db9/classpage_rank.html',1,'']]],
  ['pagerankbyrelevance_1',['PageRankByRelevance',['../da/dcf/class_page_rank_by_relevance.html',1,'']]],
  ['phrasesearching_2',['phraseSearching',['../d4/dee/classphrase_searching.html',1,'']]]
];
