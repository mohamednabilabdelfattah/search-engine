var searchData=
[
  ['pagerank_2ejava_0',['pageRank.java',['../d9/d9f/page_rank_8java.html',1,'']]],
  ['pagerankbyrelevance_2ejava_1',['PageRankByRelevance.java',['../d2/de0/_page_rank_by_relevance_8java.html',1,'']]],
  ['phrasesearching_2ejava_2',['phraseSearching.java',['../d5/df8/phrase_searching_8java.html',1,'']]]
];
