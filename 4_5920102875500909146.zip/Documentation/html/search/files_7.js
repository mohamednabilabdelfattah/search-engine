var searchData=
[
  ['queryprocessor_2ejava_0',['QueryProcessor.java',['../da/da3/_query_processor_8java.html',1,'']]]
];
