var searchData=
[
  ['phrasesearch_0',['phraseSearch',['../d4/dee/classphrase_searching.html#aa80dc48cc87a8240671fca6564be4201',1,'phraseSearching']]],
  ['pushurlintononcrawled_1',['pushURLIntoNonCrawled',['../dc/da4/class_crawler.html#ad98dd939dcb874c975a429b354bd30be',1,'Crawler']]]
];
