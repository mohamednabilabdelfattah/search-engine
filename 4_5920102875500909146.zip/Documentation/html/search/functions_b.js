var searchData=
[
  ['updatetherankoftheurl_0',['updateTheRankOfTheURL',['../d8/d9e/class_d_b_manager.html#a1a06c0ab17c245a02e6c637e89d7cc08',1,'DBManager']]]
];
